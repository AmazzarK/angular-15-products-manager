export interface Product {
  id?: string;
  label: string;
  price: number;
  thumbnail: string;
}
